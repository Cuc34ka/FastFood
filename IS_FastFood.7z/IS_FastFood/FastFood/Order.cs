﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFood
{
    public partial class Order : Form
    {
        public Order()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form Main_menu = new Main_menu();
            Main_menu.Show();
            button4.Enabled = false;
            this.Visible = false;
        }
    }
}
